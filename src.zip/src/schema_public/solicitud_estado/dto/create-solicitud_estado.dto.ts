export class CreateSolicitudEstadoDto {}
