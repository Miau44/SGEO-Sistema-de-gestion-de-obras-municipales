export class SolicitudEstado {}
