export class CreateTipoInformeDto {}
