export class CreateTipoDocumentoDto {}
