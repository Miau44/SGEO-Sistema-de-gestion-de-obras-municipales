export class CreateEstadoGeneralDto {}
