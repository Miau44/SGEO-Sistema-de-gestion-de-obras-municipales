export class CreateEstadoSolicitudDto {}
