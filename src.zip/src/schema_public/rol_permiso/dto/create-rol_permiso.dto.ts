export class CreateRolPermisoDto {}
