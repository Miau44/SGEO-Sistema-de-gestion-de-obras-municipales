export class CreateEstructuraOrganizacionalDto {}
