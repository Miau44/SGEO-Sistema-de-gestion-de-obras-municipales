export class CreateExternoDto {}
