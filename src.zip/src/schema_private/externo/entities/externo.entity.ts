export class Externo {}
